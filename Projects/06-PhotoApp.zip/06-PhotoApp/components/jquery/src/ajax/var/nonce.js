define([
	"../../core"
], function( jQuery ) {
	return jQuery.now();
});
